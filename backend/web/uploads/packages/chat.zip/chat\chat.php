<?php 
namespace frontend\modules\chat;

/**
 * Description of module
 *
 * @author OneLab
 */
class chat extends \yii\base\Module{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'frontend\modules\chat\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
